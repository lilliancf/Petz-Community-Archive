Unzip this file into your Resource/Catz directory (same folder as the breed file).

If it doesn't create a folder called "fn", make this folder and put the sounds and fnsn.txt file into it.