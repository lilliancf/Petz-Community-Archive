To hear your lemurs "talk" these enclosed files:

rtsnd.txt
rt_angry.wav
rt_grunt.wav
rt_happy.wav
rt_howl.wav
rt_sigh.wav

need to be extracted to the following directly (in your petz game wherever it was installed).  "Petz 5\ptzfiles\cat\rt"

If the folders don't exist or this zip file dosn't create them, create them yourself.


Enjoy your new petz!


Vickie Boutwell
spark13@hotmail.com