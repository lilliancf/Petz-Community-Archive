To hear your hamsterz "talk" these enclosed files:

hmsnd.txt
bquiek2.wav
chipmonk.wav
chuckle.wav
cooing3.wav
hello1.wav
keck.wav
mousesqueak.wav
mousesqueak2.wav
pain.wav
pd1.wav
purr.wav
rat.wav
squeeker.wav
squirrel.wav
tmn.wav

need to be extracted to the following directly (in your petz game wherever it was installed).  "Petz 5\ptzfiles\cat\hm"

If the folders don't exist or this zip file dosn't create them, create them yourself.


Enjoy your new petz!


Vickie Boutwell
spark13@hotmail.com