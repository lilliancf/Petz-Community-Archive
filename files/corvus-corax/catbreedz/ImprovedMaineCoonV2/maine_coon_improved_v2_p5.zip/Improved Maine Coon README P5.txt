
"Improved" Maine Coon for Petz/Catz 5
Corvus Corax
http://www.geocities.com/educ82libr8/

This version of the Improved Maine Coon is by  Random Wiktor of Corvus Corax. This is how she described her breed:

	"Improved" Maine Coon
	Yes, this is a horrible file, but it was my first catz. And at least its not a big headed, texture-ridden potato like the PFM one.

Random created this breed for Petz 4 & 5. The conversion to Petz 3 was done by Minibyte. The conversion is an exact duplicate of the original breed. None of Random's coding has been changed. The file was simply ported to a different game version. 
Have fun!

Minibyte
November 9, 2004


