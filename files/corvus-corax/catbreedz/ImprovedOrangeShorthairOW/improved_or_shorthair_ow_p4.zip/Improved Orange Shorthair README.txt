
Improved Orange Shorthair
Corvus Corax
http://www.geocities.com/educ82libr8/

This version of the Orange Shorthair is by  Random Wiktor of Corvus Corax. This is how she described her breed:

	Improved Orange Shorthair

	I still want to bludgeon it to death for its personality, but at least now I will be doing it for the way it acts and not the way it looks.

Random created this breed for Petz 5. The conversions to Petz 3 and Petz 4 were done by Minibyte. The conversions are exact duplicates of the original breed. None of Random's coding has been changed. The file was simply ported to different game versions. 

BE SURE TO SAVE YOUR ORIGINAL ORANGE SHORTHAIR.CAT FILE TO A FLOPPY DISK OR CD FIRST! This file will overwrite the Dalmatian.dog breed file that comes with the game.

Minibyte
January 29, 2005
