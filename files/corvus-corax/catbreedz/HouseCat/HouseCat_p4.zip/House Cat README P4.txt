
House Cat for Petz/Catz 4
Corvus Corax
http://www.geocities.com/educ82libr8/

This version of the House Cat is by  Random Wiktor of Corvus Corax. This is how she described her breed:

	  Housecatz
This is supposed to looks like your every day, chubby, mix bred house cat. It comes in 8 or 9 colors, and is just kind of cute.

Random created this breed for Petz 5. Conversions to Petz 3 and Petz 4 have been done by Minibyte. The conversions are exact duplicates of the original breed. None of Random's coding has been changed. The file was simply ported to different game versions. 
Have fun!

Minibyte
November 9, 2004


