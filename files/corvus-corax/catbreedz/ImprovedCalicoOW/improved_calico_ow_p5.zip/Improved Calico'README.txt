
"Improved" Calico
Corvus Corax
http://www.geocities.com/educ82libr8/

This version of the Improved Calico is by  Random Wiktor of Corvus Corax. This is how she described her breed:

	Improved Calico
A slightly more realistic variation of the PFM calico, which they for some reason decided had a larger head than body.

Random created this breed for Petz 5. Conversions to Petz 3 and Petz 4 have been done by Minibyte. The conversions are exact duplicates of the original breed. None of Random's coding has been changed. The file was simply ported to different game versions. 
Have fun!

Minibyte
January 28, 2005


