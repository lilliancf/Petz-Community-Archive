
"Improved" Maine Coon for Version 1
Corvus Corax
http://www.geocities.com/educ82libr8/

This version of the Improved Maine Coon is by  Random Wiktor of Corvus Corax. This is how she described her breed:

	"Improved" Maine Coon
	The PFM Maine Coon, with its large head, anorexic neck, and hideous texture is a blasphemy against its beautiful real life counter part. So is this breed, but at least it has a ruff and feathing. P.S. Rizza - I made my own ruff, sorry aboot the mix up.

Random created this breed for Petz 5. Conversions to Petz 3 and Petz 4 have been done by Minibyte. The conversions are exact duplicates of the original breed. None of Random's coding has been changed. The file was simply ported to different game versions. 
Have fun!

Minibyte
January 27, 2005


