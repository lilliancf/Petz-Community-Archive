
Angora Catz 4 Revision 1
Corvus Corax
http://www.geocities.com/educ82libr8/

This is Revision 1, the corrected version of the Catz 4 Angora breed file by  Random Wiktor of Corvus Corax. This is how she described her breed:

	Angora Rabbit - WKC Accepted
All credit for the base of this breed goes to Lindz. You can find a link to her website at the WKC's accepted species page. One color, sorry.
	
The original Catz 4 Version of the Angora posted on the Corvus Corax site had an incorrect offset (an internal breed identification number). It had the same offset as the Persian Cat. That meant it would either not show up in the Adoption Center or it would cause serious breeding problems. I corrected the number in this version.

Minibyte
November 23, 2004




