
Angora Catz 3
Corvus Corax
http://www.geocities.com/educ82libr8/

This is the Catz 5 version of the Angora breed file by  Random Wiktor of Corvus Corax. This is how she described her breed:

	Angora Rabbit - WKC Accepted
All credit for the base of this breed goes to Lindz. You can find a link to her website at the WKC's accepted species page. One color, sorry.
	
Random created this breed for Catz 4 and 5. This conversion to Petz 3 was done by Minibyte. The conversion is an exact duplicate of the original breed. None of Random's coding has been changed. The file was simply ported to a different game version.

Minibyte
November 23, 2004




