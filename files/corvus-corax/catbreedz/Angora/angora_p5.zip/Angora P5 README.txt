
Angora Catz 5
Corvus Corax
http://www.geocities.com/educ82libr8/

This is the Catz 5 version of the Angora breed file by  Random Wiktor of Corvus Corax. This is how she described her breed:

	Angora Rabbit - WKC Accepted
All credit for the base of this breed goes to Lindz. You can find a link to her website at the WKC's accepted species page. One color, sorry.
	
Random created this breed for Catz 4 and 5.

Minibyte
November 23, 2004




