
Australian Cattle Dog
Corvus Corax
http://www.geocities.com/educ82libr8/

This version of the Australian Cattle Dog is by  Random Wiktor of Corvus Corax. This is how she described her breed:

	Australian Cattle Dog*

	I finally finished this breed; I know the differences don't look huge, but the 	muzzle, torso, and legs are actually dramatically different. I also made a new fur file, which looks 100 times better than the old one. Expect to see a the red merle soon!  * I chose to not get this breed PKC approved so I could have more creative freedom with it.

Random created this breed for Petz 5. The conversions to Petz 3 and Petz 4 were done by Minibyte. The conversions are exact duplicates of the original breed. None of Random's coding has been changed. The file was simply ported to different game versions. 

Place the Dalmatian.dog and blum.bmp into the Resource\Dogz folder. BE SURE TO SAVE YOUR ORIGINAL DALMATIAN.DOG FILE TO A FLOPPY DISK OR CD FIRST! This file will overwrite the Dalmatian.dog breed file that comes with the game.

Minibyte
January 20, 2005
