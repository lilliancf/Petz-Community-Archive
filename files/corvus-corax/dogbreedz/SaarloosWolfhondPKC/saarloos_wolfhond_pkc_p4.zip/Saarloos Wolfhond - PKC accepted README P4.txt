
Saarloos Wolfhond for Petz/Dogz 4
Corvus Corax
http://www.geocities.com/educ82libr8/

This version of the Saarloos Wolfhond is by  Random Wiktor of Corvus Corax. This is how she described her breed:

	Saarloos Wolfhond - PKC Accepted
My first shot at the Saarloos, back when I had not much experience with the linez 	section, hence the lumpy topline and 2nd gen tail problems. Iit only comes in the color shown, but the 2st genners can be shown in the PKC.

Random created this breed for Petz 5. Conversions to Petz 3 and Petz 4 have been done by Minibyte. The conversions are exact duplicates of the original breed. None of Random's coding has been changed. The file was simply ported to different game versions. 
Have fun!

Minibyte
November 9, 2004


