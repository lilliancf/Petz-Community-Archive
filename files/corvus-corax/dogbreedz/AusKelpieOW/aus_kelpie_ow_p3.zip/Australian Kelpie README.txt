
Australian Kelpie
Corvus Corax
http://www.geocities.com/educ82libr8/

This version of the Australian Kelpie is by  Random Wiktor of Corvus Corax. This is how she described her breed:

	Australian Kelpie
	
	I made this breed a while back (it used to have several color var) but was never really please with it. I still don't like it too much, so I might take it down and edit it some more, but right now its looking way better than it did. The file only has brown right now, I'll be posting the other colors in our upcoming "variations" page.

Random created this breed for Petz 5. The conversions to Petz 3 and Petz 4 were done by Minibyte. The conversions are exact duplicates of the original breed. None of Random's coding has been changed. The file was simply ported to different game versions. 

 BE SURE TO SAVE YOUR ORIGINAL DALMATIAN.DOG FILE TO A FLOPPY DISK OR CD FIRST! This file will overwrite the Dalmatian.dog breed file that comes with the game.

Minibyte
January 22, 2005
