
Akita Inu
Corvus Corax
http://www.geocities.com/educ82libr8/

This version of the Akita is by  Random Wiktor of Corvus Corax. It has been given the Japanese name so that it won't overwrite other Akita files.

Random created this breed for Petz 5. The conversions to Petz 3 and Petz 4 were done by Minibyte. The conversions are exact duplicates of the original breed. None of Random's coding has been changed. The file was simply ported to different game versions.

Minibyte
November 3, 2004
