
Saarloos Wolfhond for Petz/Dogz 3
Corvus Corax
http://www.geocities.com/educ82libr8/

This version of the Saarloos Wolfhond is by  Random Wiktor of Corvus Corax. This is how she described her breed:

	Saarloos Wolfhond - NOT PKC Accepted
	I made this to correct the 2nd gen tail and eye problems of the origional file, as 	well as exersize my new knowledge of color variations. I think the nose has issues. Sorry.  

Random created this breed for Petz 5. Conversions to Petz 3 and Petz 4 have been done by Minibyte. The conversions are exact duplicates of the original breed. None of Random's coding has been changed. 

Have fun!

Minibyte
November 8, 2004


