
Siberian Husky
Corvus Corax
http://www.geocities.com/educ82libr8/

This version of the Siberian Husky is by  Random Wiktor of Corvus Corax. This is how she described her breed:

	Siberian Husky
	I was coerced into making this breed by someone desparate for a new husky file. While I was in the middle of making it, naturally about 4 people came out with their own huskies. It has tons of color, eye, and nose variations.

Random created this breed for Petz 3. Conversions to Petz 4 and Petz 5 were done by Minibyte. The conversions are exact duplicates of the original breed. None of Random's coding has been changed. The file was simply ported to different game versions. 
Have fun!

Minibyte
November 9, 2004


