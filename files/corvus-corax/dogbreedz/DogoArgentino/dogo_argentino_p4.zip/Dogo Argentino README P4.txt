
Dogo Argentino for Petz/Dogz 3
Corvus Corax
http://www.geocities.com/educ82libr8/

This version of the Dogo Argentino is by  Random Wiktor of Corvus Corax. This is her comment about the breed:
	
	 Dogo Argentino
	I don't like any Dogo files out there, so I made my own. Doesn't mean I like it, just means I can complain now because I tried it too.

Random created this breed for Petz 3, Petz 4 and Petz 5 with Resource Hacker. Resource Hacker is infamous for corrupting files. While the Dogz 3 version worked, it was corrupted and conversions to Dogz 4 and 5 crashed the game. I have fixed all three versions of the file. 

Have fun!

Minibyte
November 5, 2004


