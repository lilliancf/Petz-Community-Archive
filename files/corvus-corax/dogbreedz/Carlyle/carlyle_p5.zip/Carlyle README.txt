
Carlyle
Corvus Corax
http://www.geocities.com/educ82libr8/

This is a breed based upon a real life pet. Here is what Random posted about Carlyle:

	ARF Dogz - Based on canine residents of the Animal Rescue Foundation in Beacon, NY.  
	Carlyle
 
	Carlyle is a hound/setter mix who was surrendered to ARF after being used as a blood 	donor animal for 5 years at a veterinary hospital. Although he is still has a few 	behavioral issues, he is making great progress and we all hope he finds a great home 	soon. He is an active and affectionate dog.

	This breed was hexed with Jess's permission from the Abno Golden Retriever

Random created this breed for Petz 3, 4 and 5. 

Minibyte
January 6, 2005
