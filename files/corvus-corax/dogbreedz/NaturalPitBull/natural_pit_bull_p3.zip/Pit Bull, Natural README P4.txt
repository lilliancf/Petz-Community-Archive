
Pit Bull, Natural for Petz/Dogz 3
Corvus Corax
http://www.geocities.com/educ82libr8/

This version of the Pit Bull, Natural is by  Random Wiktor of Corvus Corax. This is how she described her breed:
	
	Pit Bull - Natural

	Finally fixed with no 2nd gen errors, 13 color var, 5 nose color var, and a slightly improved head shape.

Random created this breed for Petz 3, Petz 4 and Petz 5. 

Have fun!

Minibyte
November 4, 2004


