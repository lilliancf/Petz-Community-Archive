
Alaskan Malamute for Petz/Dogz 4
Corvus Corax
http://www.geocities.com/educ82libr8/

This version of the Alaskan Malamute breed was created by  Random Wiktor of Corvus Corax. This is her comment about the breed:
	
	Alaskan Malamute
	Been a while since I've done a nice fluffy breed. Its got variations, I forget how 	many, including nose color var. Don't bitch about it not being "chubby" enough 	unless you plan on hexing a file yourself.

Random created this breed for Petz 3, Petz 4 and Petz 5. 

Have fun!

Minibyte
November 5, 2004


