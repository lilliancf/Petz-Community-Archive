
Lil Bear
Corvus Corax
http://www.geocities.com/educ82libr8/

This is a breed based upon a real life pet. Here is what Random posted about Lil Bear:

	ARF Dogz - Based on canine residents of the Animal Rescue Foundation in Beacon, NY.  
	Lil Bear

	Bear has been living at ARF since he was a puppy - for the past 6 years. His owner 	"accidentally" broke his leg, then gave him to ARF to avoid paying medical bills. 	Lil Bear was badly traumatized, and does not like to be pet by anyone but Joanie. He 	barked for the first time last year, and loves Trudy the dog.

Random created this breed for Petz 5. The conversions to Petz 3 and Petz 4 were done by Minibyte. The conversions are exact duplicates of the original breed. None of Random's coding has been changed. The file was simply ported to different game versions. 

Minibyte
January 6, 2005
