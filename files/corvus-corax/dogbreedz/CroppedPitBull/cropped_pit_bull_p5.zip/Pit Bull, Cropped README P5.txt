
Pit Bull, Cropped for Petz/Dogz 5
Corvus Corax
http://www.geocities.com/educ82libr8/

This version of the Pit Bull, Cropped is by  Random Wiktor of Corvus Corax. This is how she described her breed:
	
	Pit Bull - Cropped
	Despite my moral objections to cropping, I've made this updated cropped file. Has same 13 var and 5 nose var as the nat. file.

Random created this breed for Petz 3, Petz 4 and Petz 5. 

Have fun!

Minibyte
November 4, 2004


