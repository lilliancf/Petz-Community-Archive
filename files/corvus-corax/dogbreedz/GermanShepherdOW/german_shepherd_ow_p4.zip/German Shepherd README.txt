
German Shepherd
Corvus Corax
http://www.geocities.com/educ82libr8/

This version of the German Shepherd is by  Random Wiktor of Corvus Corax. This is how she described her breed:

	German Shepherd
	
	A non wildz breed, I hexed the german shepherd for kicks, and cause I hate the ubisoft one. Its not very well made, but I will probably update it. And yes it looks similar to the dingo, they have the same ear type. (When I make a good eartype, I'll save a copy of the dali with the cool ears to make other breeds with, hence some of our breeds similar ears.)

Random created this breed for Petz 5. The conversions to Petz 3 and Petz 4 were done by Minibyte. The conversions are exact duplicates of the original breed. None of Random's coding has been changed. The file was simply ported to different game versions. 

Place the Dalmatian.dog file into the Resource\Dogz folder. BE SURE TO SAVE YOUR ORIGINAL DALMATIAN.DOG FILE TO A FLOPPY DISK OR CD FIRST! This file will overwrite the Dalmatian.dog breed file that comes with the game.

Minibyte
February 10, 2005
