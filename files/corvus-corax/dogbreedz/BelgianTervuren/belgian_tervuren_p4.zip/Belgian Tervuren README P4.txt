
Belgian Tervuren for Petz/Dogz 4
Corvus Corax
http://www.geocities.com/educ82libr8/

The Belgian Tervuren breed was created by  Random Wiktor of Corvus Corax. This is how she described her breed:
	
	Belgian Tervuren - PKC Accepted
	This one time, I was bringing an escaped dog back to its owner, and their other dog, also lose, attacked me. It happened to be a Belgian Tervuren, so I decided to hex that breed. Should be compatible with all OS.

Random created this breed for Petz 3, Petz 4 and Petz 5. 

Have fun!

Minibyte
November 4, 2004


