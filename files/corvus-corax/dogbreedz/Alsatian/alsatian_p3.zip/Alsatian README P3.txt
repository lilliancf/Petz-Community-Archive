
Alsatian (German Shepherd) for Petz/Dogz 3
Corvus Corax
http://www.geocities.com/educ82libr8/

This version of the Alsatian is by  Random Wiktor of Corvus Corax. This is how she described her breed:

	Alsatian
	Ever notice how most gsheps in petz have super-angled legs? I did, so I've made a more working type german shepherd. It comes in several colors, some of which probably aren't realistic, as well as a longhaired variations

Random created this breed for Petz 3. Conversions to Petz 4 and Petz 5 have been done by Minibyte. The conversions are exact duplicates of the original breed. None of Random's coding has been changed. The file was simply ported to different game versions. 

Have fun!

Minibyte
November 8, 2004


