
Saarloos Wolfhond.dog
http://randomwiktor.conforums.com/index.cgi

This version of the Saarloos Wolfhond  is by Random Wiktor of the now closed Corvus Corax. This is how she described her breed:

	Created by Leendert Saarloos by crossing german shepherds and wolves, the Saarloos Wolfhond (also called the Saarloos Wolfhound or European Wolfdog) is a large, strong-willed, and robust dog. They look not unlike a thin, shorter-pelted wolf, and have both wolf and dog behavioral aspects. This can make them a challenging breed to own and train, which has lead to the ban of the Saarloos Wolfhond in several contries. However, with careful training and a good human-animal understanding, they make far more stable pets than wolf hybrids, being largely dog in lineage.
	
	This breed file is a little different from my others in that it is more old fashioned. It has "normal" eyes and is not super-realistic. It comes in 23 variations (mostly due to different transitional leg markings and liver variations). The eye/nose/claw color corresponds to liver and non-liver expectations. This breed could probably be PKC accepted, and was in the process of being accepted when I quit hexing it for some time. It will not be going for acceptance, nor is it the accepted file listed on their breed list. Please do not attempt to show this breed; use the older version, or request its acceptance.


Random created this breed for Petz 5. Conversions to Petz 3 and Petz 4 have been done by Minibyte. The conversions are exact duplicates of the original breed. 


Have fun!

Minibyte
June 7, 2006


