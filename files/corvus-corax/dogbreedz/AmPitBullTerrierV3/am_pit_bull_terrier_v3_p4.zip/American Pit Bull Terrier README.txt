
American Pit Bull Terrier for Petz/Dogz 4
Corvus Corax
http://www.geocities.com/educ82libr8/

This version of the American Pit Bull Terrier is by  Random Wiktor of Corvus Corax. This is how she described her breed:

	This is my last pit bull file... honest to God. It has 5 ear types, 2 tail types, 40 color varitaions, and several nose color varitaions. Don't expect me to ever put this much effort into a breed ever again, because it took a long time and wasn't really worth the effort. Regardless, enjoy.
	
	Note: grey eyes NOT in file... I don't know what I was thinking. 

Random created this breed for Petz 5. The conversions to Petz 3 and Petz 4 were done by Minibyte. The conversions are exact duplicates of the original breed. None of Random's coding has been changed. The file was simply ported to different game versions.

This breed uses a texture from the Tabby cat. Textures (bitmaps) are treated differently in Petz 5 than they are in Petz 3 or Petz 4. In order for your Pit Bull Terrier petz to have the appropriate texture amd to have them import properly into Petz 5, you will need to set up some folders for the enclosed bitmap.

Find the folder called either Petz 4 if you have both the Catz and Dogz games or the folder called Dogz 4 if you have only the Dogz game. Make a new folder there and call it art. Inside the art folder make a new folder and call it textures. Put the stripe11.bmp into that textures folder. It should look like this:

Petz 4\art\textures\stripe11.bmp

or, if you have only the Dogz game:

Dogz 4\art\texture\stripe11.bmp

Once you have done this, your American Pit Bull Terriers will be able to use the Tabby cat texture when it is needed and Petz 5 players will be able to adopt your petz and import them with no problem. NOTE!! Petz 5 players do not need either the stripe11.bmp or a special setup because the file is already in their game.

Have fun!

Minibyte
November 3, 2004


