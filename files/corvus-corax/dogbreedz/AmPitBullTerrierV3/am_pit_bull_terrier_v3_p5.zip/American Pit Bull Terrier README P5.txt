
American Pit Bull Terrier for Petz/Dogz 5
Corvus Corax
http://www.geocities.com/educ82libr8/

This version of the American Pit Bull Terrier is by  Random Wiktor of Corvus Corax. This is how she described her breed:

	This is my last pit bull file... honest to God. It has 5 ear types, 2 tail types, 40 color varitaions, and several nose color varitaions. Don't expect me to ever put this much effort into a breed ever again, because it took a long time and wasn't really worth the effort. Regardless, enjoy.
	
	Note: grey eyes NOT in file... I don't know what I was thinking. 

Random created this breed for Petz 5. Conversions to Petz 3 and Petz 4 have been done by Minibyte. The conversions are exact duplicates of the original breed. None of Random's coding has been changed. The file was simply ported to different game versions. HOWEVER, because this breed uses a texture from the Tabby Cat and Petz 5 treats bitmaps differently than Petz 3 or 4, Petz 4 and 5 gamers have to set up the files a certain way. PETZ 5 GAMERS DO NOT NEED THE STRIPE11.BMP OR THE SPECIAL SETUP BECAUSE THE FILE IS ALREADY IN THEIR GAME.

Petz 5 players need only to place the PitBullTerrier.dog file into the Dogz folder and they are ready to adopt a Pit Bull puppy.

Have fun!

Minibyte
November 3, 2004


