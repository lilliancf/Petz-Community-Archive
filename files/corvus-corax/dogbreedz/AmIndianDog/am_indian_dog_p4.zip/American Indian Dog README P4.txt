
American Indian Dog for Petz/Dogz 4
Corvus Corax
http://www.geocities.com/educ82libr8/

This version of the American Indian Dog is by  Random Wiktor of Corvus Corax. This is how she described her breed:

	American Indian Dog
	This breed isn't accepted by any breed clubs IRL, but its just kinda cute so I decided to do it a grave injustice by trying to hex it. Comes in lots of colors (I forget how many; over 20 though), and has a mobile tail.

Random created this breed for Petz 5. Conversions to Petz 3 and Petz 4 have been done by Minibyte. The conversions are exact duplicates of the original breed. None of Random's coding has been changed. The file was simply ported to different game versions. 
Have fun!

Minibyte
November 9, 2004


